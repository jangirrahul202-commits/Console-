# Salesforce Apex Developer Console - Installation Guide

A lightweight Salesforce Apex code editor that opens as a standalone window, featuring:
- 🎨 Monaco Editor (VS Code engine)
- 🧪 Test Runner with Code Coverage
- 🔍 Real-time Linting (Salesforce PMD rules)
- 📊 Code Diff Checker
- 🔄 SOQL Query Builder
- ⚡ Keyboard Shortcuts & Command Palette

---

## 🚀 Quick Install (5 minutes)

### **Step 1: Download**
Download `salesforce-apex-console-v1.0.0.zip` from [your shared location]

### **Step 2: Unzip**
Extract the ZIP file to a folder on your computer (e.g., `~/Downloads/salesforce-apex-console`)

### **Step 3: Install in Chrome**
1. Open Chrome
2. Go to: `chrome://extensions/`
3. Enable **"Developer mode"** (toggle in top-right corner)
4. Click **"Load unpacked"**
5. Select the folder you unzipped in Step 2

### **Step 4: Use It!**
1. Navigate to any Salesforce org (production, sandbox, or scratch org)
2. Log in to Salesforce
3. Click the **Salesforce Apex Developer Console** icon in Chrome toolbar
4. Extension opens as a **new window** (shows in taskbar/dock!)
5. Start coding! 🎉

---

## ✨ Features

### **Code Editor**
- Syntax highlighting for Apex
- Auto-completion
- Line numbers & minimap
- Multi-tab support
- Save with `Ctrl+S` / `Cmd+S`

### **Test Runner**
- Click "Run Test" on any test class
- View pass/fail results
- See execution time
- View stack traces for failures

### **Code Coverage**
- Click "Show Coverage" after running tests
- Green lines = covered
- Red lines = not covered
- Coverage percentage badge in tabs
- Summary panel with all classes

### **Real-time Linting**
- Detects DML in loops
- Detects SOQL in loops
- Checks for hardcoded IDs
- Warns about debug statements
- Validates CRUD/FLS
- Problems panel with clickable errors

### **Code Diff Checker**
- Press `Ctrl+Shift+D` / `Cmd+Shift+D`
- Paste comparison code
- Side-by-side diff view
- Hover over changed lines to accept/reject
- Apply changes to editor

### **SOQL Query Builder**
- Press `Ctrl+Shift+Q` / `Cmd+Shift+Q`
- Visual query builder
- Select objects and fields
- Execute queries
- View results in table

### **Keyboard Shortcuts**
- `Ctrl+P` / `Cmd+P`: Quick file search
- `Ctrl+Shift+P` / `Cmd+Shift+P`: Command palette
- `Ctrl+S` / `Cmd+S`: Save file
- `Ctrl+Shift+D` / `Cmd+Shift+D`: Open diff checker
- `Ctrl+Shift+Q` / `Cmd+Shift+Q`: Open SOQL builder

---

## 🐛 Troubleshooting

### **Extension icon doesn't appear**
- Refresh the Salesforce page
- Make sure you're logged in
- Check that the extension is enabled in `chrome://extensions/`

### **"No Salesforce session found" error**
- Make sure you're on a Salesforce page (`*.salesforce.com` or `*.force.com`)
- Log out and log back in to Salesforce
- Try clicking the extension icon again

### **Code doesn't load**
- Click the "Refresh" button in the extension
- Check your internet connection
- Verify you have API access in Salesforce

### **Can't save code**
- Check that you have edit permissions for the class
- Verify the class is not locked by another user
- Check compilation errors in the status panel

---

## 🔒 Security & Privacy

- **No data is stored**: All code stays in your Salesforce org
- **Cookie-based auth**: Uses your existing Salesforce session
- **No external servers**: Direct communication with Salesforce API
- **Open source**: Code is available for review

---

## 📞 Support

For issues or questions:
- Contact: [Your email/Slack channel]
- Report bugs: [Your issue tracker]

---

## 🎯 Tips & Tricks

1. **Use Alt+Tab / Cmd+Tab** to switch between Chrome and the extension
2. **Maximize the window** for full IDE experience
3. **Use Quick Search** (`Ctrl+P`) to quickly find classes
4. **Run tests first**, then check coverage
5. **Hover over linting errors** to see details
6. **Use the diff checker** to compare versions before saving

---

## 📝 Version

Current version: **1.0.0**
Last updated: December 15, 2025

---

Enjoy coding! 🚀



