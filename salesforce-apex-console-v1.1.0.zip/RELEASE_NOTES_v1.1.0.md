# Salesforce Apex Developer Console - Release Notes v1.1.0

## 🎉 What's New in Version 1.1.0

### ✨ Major Features

#### 🤖 AI-Powered Assistant (NEW!)
- **Smart Coverage Suggestions**: Get AI-generated test methods to improve code coverage
  - Analyzes uncovered lines and suggests specific test cases
  - Shows exactly which lines each test will cover
  - Includes complete, copy-paste-ready test code
  - Powered by Perplexity API (requires API key)
  
- **Debug Log Analysis**: AI analyzes error logs and provides solutions
  - Root cause analysis of errors
  - Multiple fix options with code examples
  - Performance optimization suggestions
  - Prevention strategies

- **Settings Panel**: Configure AI assistant
  - Add/update API key
  - Select model (sonar, sonar-pro, sonar-reasoning)
  - View usage statistics (tokens used, estimated cost)
  - View suggestion history

#### 🔍 Debug Log Viewer (NEW!)
- Fetch and view debug logs from your Salesforce org
- Parse and analyze log events:
  - SOQL queries
  - DML statements
  - CPU time
  - Heap size
  - Errors and stack traces
- Filter logs by operation type
- Delete old logs
- View detailed log body
- Create trace flags automatically

#### 📊 Enhanced Coverage Panel
- New "Lines Needed" indicator showing how many more lines to reach 75% coverage
- "🤖 AI Suggest" button for classes below 75% coverage
- Visual indicators for coverage status

### 🔧 Improvements

#### SOQL Query Builder
- Build and test SOQL queries visually
- Auto-complete for objects and fields
- Live query execution
- Results displayed in formatted JSON

#### Inline Diff Checker
- Compare code side-by-side with inline arrows
- Hover-activated change arrows
- Accurate diff algorithm using LCS (Longest Common Subsequence)
- Real-time visual updates when moving code
- Synchronized scrolling between panels

#### Better Linting
- Improved accuracy based on Salesforce PMD rules
- Fewer false positives
- Clear error messages with line numbers

### 🐛 Bug Fixes
- Fixed "Invalid bounds" error when opening extension on different screen sizes
- Fixed resizable panel direction (now expands/collapses correctly)
- Fixed diff algorithm showing false modifications
- Fixed window behavior to work like Lightning Studio (full-screen popup with dock icon)

---

## 📦 Installation Instructions

### For Recipients (Testing)

1. **Extract the Package**
   ```bash
   unzip salesforce-apex-console-v1.1.0.zip
   ```

2. **Load in Chrome**
   - Open Chrome and go to: `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)
   - Click "Load unpacked"
   - Select the `dist/` folder from the extracted package

3. **Setup AI Assistant (Optional)**
   - Get a free API key from Perplexity: https://www.perplexity.ai/settings/api
   - Open extension settings (Cmd+, or click Settings button)
   - Enter your API key
   - Select model (start with "sonar" - cheapest option)

4. **Use the Extension**
   - Log in to your Salesforce org
   - Navigate to any Salesforce page
   - Click the extension icon in Chrome toolbar
   - Extension opens as a full-screen window

---

## 🚀 Quick Start Guide

### Basic Usage
1. Click extension icon → opens in new window
2. Browse Apex classes in left sidebar
3. Click a class to open it in the editor
4. Edit code with real-time linting
5. Save with Cmd+S or Ctrl+S

### Run Tests & Check Coverage
1. Open a test class
2. Click "Run Test" button
3. View results in Coverage panel
4. Click "Show Coverage" to highlight covered/uncovered lines
5. Click "🤖 AI Suggest" for coverage improvement tips

### Debug Logs
1. Click "Debug Log" button in header
2. View recent logs
3. Click a log to see parsed events
4. If errors present, click "🤖 AI Analyze" for solutions

### Compare Code (Diff Checker)
1. Open the class you want to compare
2. Press Cmd+Shift+D (or Ctrl+Shift+D)
3. Paste the comparison code in the right panel
4. Hover over changed lines to move code between panels

### SOQL Query Builder
1. Press Cmd+Shift+Q (or Ctrl+Shift+Q)
2. Select object and fields
3. Add WHERE clauses, ORDER BY, LIMIT
4. Click "Execute Query"
5. View results

---

## 🔑 Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Cmd+S` / `Ctrl+S` | Save current file |
| `Cmd+Shift+D` / `Ctrl+Shift+D` | Open Diff Checker |
| `Cmd+Shift+Q` / `Ctrl+Shift+Q` | Open SOQL Query Builder |
| `Cmd+,` / `Ctrl+,` | Open Settings |

---

## 💡 AI Assistant Tips

### Getting the Best Results

1. **For Coverage Suggestions:**
   - Make sure your test class is selected
   - Click "🤖 AI Suggest" on classes with <75% coverage
   - The AI will analyze uncovered lines and provide specific test methods
   - Copy the test code directly into your test class

2. **For Debug Log Analysis:**
   - Run the operation that's causing errors
   - Fetch logs using Debug Log viewer
   - Click "🤖 AI Analyze" on logs with errors
   - AI provides root cause, fixes, and prevention strategies

3. **Model Selection:**
   - **sonar**: Fastest, cheapest ($0.20/1M tokens) - great for most use cases
   - **sonar-pro**: Better quality ($1.00/1M tokens) - for complex issues
   - **sonar-reasoning**: Most advanced ($5.00/1M tokens) - for very complex debugging

4. **Cost Management:**
   - View usage stats in Settings
   - Reset stats monthly to track spending
   - Start with "sonar" model for testing
   - Typical request costs $0.001 - $0.005

---

## 🔒 Privacy & Security

- All code stays in your browser - never sent to external servers (except AI requests)
- AI requests only include the specific code/logs you're analyzing
- Your Salesforce session is read-only from cookies
- API key is stored locally in Chrome storage (not on any server)
- No data collection or telemetry

---

## 🐞 Known Issues

1. **Monaco Editor Performance**: Very large files (>5000 lines) may be slow to load
2. **Diff Checker**: Works best with structured code (may struggle with massive unformatted code)
3. **AI Rate Limits**: Perplexity API has rate limits (15 requests/min on free tier)

---

## 📝 Feedback & Support

If you encounter issues or have suggestions:
1. Check the INSTALLATION_GUIDE.md for troubleshooting
2. Ensure you're using Chrome version 88 or higher
3. Try reloading the extension: chrome://extensions/ → Reload
4. Clear extension storage if needed

---

## 🎯 What's Coming Next (Roadmap)

- [ ] Multi-provider AI support (Gemini, Groq, OpenAI, Claude)
- [ ] Inline code suggestions while typing
- [ ] Auto-fix for linting errors
- [ ] Git integration for version control
- [ ] Export test coverage reports
- [ ] Bulk operations (run all tests, deploy multiple classes)
- [ ] Custom code snippets
- [ ] Dark/Light theme toggle

---

## 📊 Version History

### v1.1.0 (Current)
- Added AI Assistant with Perplexity integration
- Added Debug Log Viewer
- Added SOQL Query Builder
- Added Inline Diff Checker
- Enhanced Coverage Panel
- Improved linting accuracy
- Fixed multiple bugs

### v1.0.0 (Initial Release)
- Basic code editor with Monaco
- Class browser and navigation
- Save and compile functionality
- Test runner
- Code coverage viewer
- Real-time linting
- Resizable panels

---

## 🙏 Credits

Built with:
- React 18 + TypeScript
- Monaco Editor (VSCode's editor)
- Zustand (state management)
- Perplexity API (AI assistant)
- Salesforce Tooling API

---

**Enjoy coding! 🚀**

