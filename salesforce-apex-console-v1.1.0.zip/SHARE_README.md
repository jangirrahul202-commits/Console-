# 🚀 Salesforce Apex Developer Console v1.1.0

A powerful Chrome Extension for Salesforce developers with AI-powered assistance.

## 📦 Quick Installation (2 Minutes)

### Step 1: Extract
```bash
unzip salesforce-apex-console-v1.1.0.zip
```

### Step 2: Load in Chrome
1. Open Chrome → `chrome://extensions/`
2. Toggle **"Developer mode"** (top right)
3. Click **"Load unpacked"**
4. Select the **`dist/`** folder

### Step 3: Use It!
1. Log in to your Salesforce org
2. Click the extension icon (cloud icon in Chrome toolbar)
3. Start coding! ✨

---

## 🎯 What Can It Do?

### ✅ Core Features
- 📝 **Code Editor** - Monaco editor (like VSCode) for Apex
- 🔍 **Real-time Linting** - Catch errors as you type
- ✅ **Test Runner** - Run tests and view coverage
- 📊 **Coverage Viewer** - See which lines are covered
- 💾 **Auto-save** - Saves to Salesforce on Cmd+S

### ✨ New in v1.1.0
- 🤖 **AI Assistant** - Get coverage suggestions & debug help
- 🐛 **Debug Log Viewer** - Analyze logs with AI
- 🔄 **Diff Checker** - Compare code side-by-side
- 🔍 **SOQL Builder** - Build queries visually

---

## 🤖 AI Assistant Setup (Optional but Awesome!)

### Get Free API Key (30 seconds)
1. Go to: https://www.perplexity.ai/settings/api
2. Sign up (free, no credit card needed)
3. Copy your API key (starts with `pplx-`)

### Add to Extension
1. Open extension → Click **Settings** (⚙️ icon)
2. Paste API key
3. Select model: **"sonar"** (cheapest, works great!)
4. Done! 🎉

### What Can AI Do?
- **Coverage < 75%?** → Click "🤖 AI Suggest" for test methods
- **Debug log errors?** → Click "🤖 AI Analyze" for solutions
- Get actual code fixes, not just explanations!

**Cost**: ~$0.001 per request (your $5 credit = ~5000 requests!)

---

## 📋 Common Issues & Fixes

### ❌ Extension Icon Not Showing
**Fix**: Refresh the extensions page and reload

### ❌ "Invalid bounds" Error
**Fix**: This version is fixed! Just reload the extension

### ❌ "Please log in to Salesforce" Message
**Fix**: Make sure you're logged into a Salesforce org first

### ❌ AI Not Working
**Check**:
1. API key starts with `pplx-`
2. You have internet connection
3. You haven't hit rate limits (15 requests/min)

---

## ⌨️ Keyboard Shortcuts

| Windows/Linux | Mac | Action |
|---------------|-----|--------|
| `Ctrl+S` | `Cmd+S` | Save file |
| `Ctrl+Shift+D` | `Cmd+Shift+D` | Diff Checker |
| `Ctrl+Shift+Q` | `Cmd+Shift+Q` | SOQL Builder |
| `Ctrl+,` | `Cmd+,` | Settings |

---

## 🎬 Quick Demo

1. **Edit Code**: Click any class → Edit → Save (Cmd+S)
2. **Run Tests**: Open test class → "Run Test" button → View coverage
3. **Get AI Help**: Click "🤖 AI Suggest" on low coverage class
4. **Check Logs**: "Debug Log" button → View errors → "🤖 AI Analyze"

---

## 📚 Full Documentation

See **RELEASE_NOTES_v1.1.0.md** for:
- Complete feature list
- Advanced usage guide
- Troubleshooting
- Roadmap

See **INSTALLATION_GUIDE.md** for:
- Detailed installation steps
- Uninstallation guide
- Privacy & security info

---

## 🔒 Privacy

- ✅ All code stays in your browser
- ✅ Only AI requests are sent externally (when you click AI buttons)
- ✅ Your Salesforce session is read-only
- ✅ No tracking or telemetry
- ✅ API key stored locally only

---

## 💬 Feedback

Found a bug? Have an idea?
Let the developer know!

---

## 🎉 Enjoy!

Happy coding! If this saves you time, share it with your team! 🚀

**Version**: 1.1.0  
**Last Updated**: December 2024  
**Requires**: Chrome 88+, Salesforce org access

